<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>file upload</title>
   <link rel="stylesheet" href="file.css">
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">

</head>
<body>
    <input type="file" id="file" accept="image/*">
    <label for="file">
        <i class="material-icons">
            add_photo_alternate 
        </i>&nbsp;
        Choose a photo
</label>
</body>
